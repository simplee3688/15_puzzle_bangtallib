﻿#define space 128
#define _CRT_SECURE_NO_WARNINGS

#include <bangtal.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>


SceneID warmind;
ObjectID startbutton, restart ;

int realNumber[16];
int countTimer;

TimerID mm;


struct Part
{
    ObjectID obj;
    int x;
    int y;
    int realNumber;
};

struct Part panel[16];

clock_t start;
clock_t end;
float clearTime;


int blankPosition = 15;
int clickCount = 0;




int findNextBlank(int x, int y);

void clickStart();

void resetPannel();

void partMaking();

void showAllPartExcept16(bool k);

int findRealPosition(ObjectID obj);

void changeTwo(int click);

void checkAllRight();

void timerCallback(TimerID timer)
{
    
    if (countTimer > 250)
    {
        countTimer = 0;
        start = clock();
        return;
    }
    resetPannel();
    increaseTimer(timer, 0.01f);
    startTimer(timer);
    countTimer++;
}

void mouseCallback(ObjectID obj, int x, int y, MouseAction act)
{
    int panelClicked;

    if (obj == startbutton)
    {
        clickStart();
        showAllPartExcept16(true);   
    }
    else if (countTimer == 0 && obj == restart)
    {
        clickStart();
        showAllPartExcept16(true);
    }
    else if(countTimer == 0)
    {
        panelClicked = findRealPosition(obj);
        printf("\nWhat you click is %d\n", panelClicked);
        if ((panelClicked + 4 == blankPosition) || (panelClicked - 4 == blankPosition) || (panelClicked % 4 != 0 && panelClicked - 1 == blankPosition) || (panelClicked % 4 != 3 && panelClicked + 1 == blankPosition))
        {
            printf("\ntrue");
            changeTwo(panelClicked);
            clickCount++;
            checkAllRight();
        }
        else
        {
            printf("\nfalse!!!!");
        }
    }
}





int main()
{

    
    
    srand(time(NULL));
    for (int i = 0; i < 16; i++)
    {
        realNumber[i] = i;
    }

    setTimerCallback(timerCallback);
    setMouseCallback(mouseCallback);
    setGameOption(GameOption::GAME_OPTION_ROOM_TITLE, false);
    setGameOption(GameOption::GAME_OPTION_INVENTORY_BUTTON, false);
    setGameOption(GameOption::GAME_OPTION_MESSAGE_BOX_BUTTON, false);

    warmind = createScene("page1" , "warmind.jpg");
    

    startbutton = createObject("start.png");
    restart = createObject("recycle.png");
    locateObject(startbutton, warmind, 590, 30);
    locateObject(restart, warmind, 1170, 610);
    showObject(startbutton);
    scaleObject(restart, 0.15f);
    hideObject(restart);

    partMaking();
    
    mm = createTimer(10.0f);
    //startTimer(mm);
    //showTimer(mm);



    startGame(warmind);
    
    
}

void checkAllRight()
{
    char justForMessage[256];
    for (int i = 0; i < 16; i++)
    {
        if (realNumber[i] != i)
        {
            printf("\n Not Yet");
            return;
        }
    }
    end = clock();
    showAllPartExcept16(false);
    setSceneImage(warmind, "warmind_clear.jpg");
    
    clearTime = float(end - start) / CLOCKS_PER_SEC;
    sprintf(justForMessage, "걸린 시간 : %0.0f 초 , 사용한 움직임 : %d 번", clearTime, clickCount);
    showMessage(justForMessage);
    clickCount = 0;
    
    return;
}

void changeTwo(int click)
{
    int temp;
    int x, y;

    printf("change %d %d\n", click, blankPosition);
    temp = realNumber[click];    
    realNumber[click] = realNumber[blankPosition];
    realNumber[blankPosition] = temp;
    for (int i = 0; i < 4; i++)
    {
        printf("%d   ", realNumber[4 * i]);
        printf("%d   ", realNumber[4 * i + 1]);
        printf("%d   ", realNumber[4 * i + 2]);
        printf("%d   \n", realNumber[4 * i + 3]);
    }
    
    x = panel[realNumber[click]].x;

    y = panel[realNumber[click]].y;

    panel[realNumber[click]].x = panel[realNumber[blankPosition]].x;

    panel[realNumber[click]].y = panel[realNumber[blankPosition]].y;

    panel[realNumber[blankPosition]].x = x;

    panel[realNumber[blankPosition]].y = y;



    for (int i = 0; i < 16; i++)
    {
        locateObject(panel[i].obj, warmind, panel[i].x, panel[i].y);   //원래 두개만 해도 되는데 머리 잘못 굴려서 망함. 머리가 안돌아가서 일단 때움
    }

    blankPosition = click;
    printf("%d \n", blankPosition);

}

void clickStart()
{
    
    countTimer = 0;
    hideObject(startbutton);
    showObject(restart);
    setTimer(mm, 0.01f);
    startTimer(mm);
    setSceneImage(warmind, "warmind_blank.jpg");
    
}

int findRealPosition(ObjectID obj)
{
    for (int i = 0; i < 16; i++)
    {
        if (panel[realNumber[i]].obj == obj)
        {
            return i;
        }
    }
}


void resetPannel()
{
    int arrow;
    int x, y;
    int newBlank = blankPosition;
    

    y = (blankPosition) / 4 + 1;
    x = ((blankPosition) % 4) + 1;
    printf("\n\n\n%d %d\n", x, y);
   
    arrow = findNextBlank(x,y);
    printf("move %d\n", arrow);
    if (arrow == 1)
    {
        newBlank = newBlank - 4;
    }
    if (arrow == 2)
    {
        newBlank = newBlank + 4;
    }
    if (arrow == 3)
    {
        newBlank = newBlank - 1;
    }
    if (arrow == 4)
    {
        newBlank = newBlank + 1;
    }
    
    
    printf("change %d %d\n", newBlank , blankPosition);
    arrow = realNumber[newBlank];    //arrow를 newblank 담는 임시 저장소로 사용한다
    realNumber[newBlank] = realNumber[blankPosition];
    realNumber[blankPosition] = arrow;
    for (int i = 0; i < 4; i++)
    {
        printf("%d   ", realNumber[4*i]);
        printf("%d   ", realNumber[4*i+1]);
        printf("%d   ", realNumber[4*i+2]);
        printf("%d   \n", realNumber[4*i+3]);
    }
    //x y를 임시 저장소로 사용한다
    x = panel[realNumber[newBlank]].x;

    y = panel[realNumber[newBlank]].y;

    panel[realNumber[newBlank]].x = panel[realNumber[blankPosition]].x;

    panel[realNumber[newBlank]].y = panel[realNumber[blankPosition]].y;

    panel[realNumber[blankPosition]].x = x;

    panel[realNumber[blankPosition]].y = y;

    

    for (int i = 0; i < 16; i++)
    {
        locateObject(panel[i].obj, warmind, panel[i].x, panel[i].y);   //원래 두개만 해도 되는데 머리 잘못 굴려서 망함. 머리가 안돌아가서 일단 때움
    }

    blankPosition = newBlank;
    printf("%d \n", blankPosition);
}

void partMaking()
{
    
    panel[0].obj = createObject("part_001.jpg");
    panel[1].obj = createObject("part_002.jpg");
    panel[2].obj = createObject("part_003.jpg");
    panel[3].obj = createObject("part_004.jpg");
    panel[4].obj = createObject("part_005.jpg");
    panel[5].obj = createObject("part_006.jpg");
    panel[6].obj = createObject("part_007.jpg");
    panel[7].obj = createObject("part_008.jpg");
    panel[8].obj = createObject("part_009.jpg");
    panel[9].obj = createObject("part_010.jpg");
    panel[10].obj = createObject("part_011.jpg");
    panel[11].obj = createObject("part_012.jpg");
    panel[12].obj = createObject("part_013.jpg");
    panel[13].obj = createObject("part_014.jpg");
    panel[14].obj = createObject("part_015.jpg");
    panel[15].obj = createObject("part_016.jpg");

    int counter = 0;

    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 4; j++)
        {
            locateObject(panel[counter].obj, warmind, 384 + (128*j), 412 - (128*i));
            panel[counter].x = 384 + (128 * j);
            panel[counter].y = 412 - (128 * i);
            counter++;
            
        }
    }
}

void showAllPartExcept16(bool k)
{
    if (k == true)
    {
        for (int i = 0; i < 15; i++)
        {
            showObject(panel[i].obj);
        }
    }
    else
    {
        for (int i = 0; i < 15; i++)
        {
            hideObject(panel[i].obj);
        }
    }
}

int findNextBlank(int x, int y)
{
    //up = 1 , down = 2 , left = 3 , right = 4
    
    if ((rand() % 2) == 0)
    {//상하 이동 관리
        if (y == 1)
        {
            return 2;
        }
        else if (y == 4)
        {
            return 1;
        }
        else
        {
            if ((rand() % 2) == 0)
            {
                return 1;
            }
            else
            {
                return 2;
            }
        }
    }
    else
    {//좌우 이동 관리
        if (x == 1)
        {
            return 4;
        }
        else if (x == 4)
        {
            return 3;
        }
        else
        {
            if ((rand() % 2) == 0)
            {
                return 3;
            }
            else
            {
                return 4;
            }
        }
    }
    
    
}

